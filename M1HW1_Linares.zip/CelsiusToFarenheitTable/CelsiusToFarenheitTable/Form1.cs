﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CelToFarClassLibrary;

namespace CelsiusToFarenheitTable
{

    /**
    * 8.21.2022
    * CSC 253
    * Lourdes Linares
    * Calculates a conversion between Celsius to Farenheit and then prints a table.
    */
    public partial class CtoFForm : Form
    {
        public CtoFForm()
        {
            InitializeComponent();
        }

        private void CtoFForm_Load(object sender, EventArgs e)
        {
            double celsius;
            double farenheit = 0;

            // To make Header
            tempListBox.Items.Add("Celsius\tFarenheit");

            //To make Table
            for (celsius = 0; celsius <= 20; celsius++)
            {
                // Call from library
                farenheit = ReferenceTable.CalcF(celsius, farenheit);
                tempListBox.Items.Add(celsius + "\t" + farenheit);
            }
        }
    }
}
