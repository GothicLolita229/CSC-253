﻿namespace CelsiusToFarenheitTable
{
    partial class CtoFForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tempListBox = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // tempListBox
            // 
            this.tempListBox.FormattingEnabled = true;
            this.tempListBox.ItemHeight = 16;
            this.tempListBox.Location = new System.Drawing.Point(1, 1);
            this.tempListBox.Name = "tempListBox";
            this.tempListBox.Size = new System.Drawing.Size(336, 308);
            this.tempListBox.TabIndex = 0;
            // 
            // CtoFForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(370, 344);
            this.Controls.Add(this.tempListBox);
            this.Name = "CtoFForm";
            this.Text = "Celsius to Farenheit Table";
            this.Load += new System.EventHandler(this.CtoFForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox tempListBox;
    }
}

