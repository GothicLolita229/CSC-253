﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CelToFarClassLibrary
{
    public class ReferenceTable
    {
        public static double CalcF(double c, double f)
        {
                return f = (9.0 / 5.0) * c + 32;
        }
        
}
}
