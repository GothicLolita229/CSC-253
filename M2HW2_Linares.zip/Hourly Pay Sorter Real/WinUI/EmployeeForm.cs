﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PDatabaseLibrary;

/* 
 *9/15/2022
 *CSC 253
 *Lourdes Linares
 *Add Buttons to Sort By Ascending and Descending Order
 *
 */

namespace WinUI
{
    public partial class EmployeeForm : Form
    {
        List<EmployeeBuilder> employee = new List<EmployeeBuilder>();
        public EmployeeForm()
        {
            InitializeComponent();

            LoadEmployeeList();
        }

        private void LoadEmployeeList()
        {
            employee = SqliteDataAccess.LoadEmployees();
            WireUpEmployeeList();
        }

        private void WireUpEmployeeList()
        {
            employeeListBox.DataSource = null;
            employeeListBox.DataSource = employee;
            employeeListBox.DisplayMember = "Info";
        }

        private void refreshButton_Click(object sender, EventArgs e)
        {
            LoadEmployeeList();
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            EmployeeBuilder emp = new EmployeeBuilder();

            emp.EmployeeID = int.Parse(eIDtextBox.Text);
            emp.Name = NameTextBox.Text;
            emp.Position = positionTextBox.Text;
            emp.Hourly = int.Parse(payRateTextBox.Text);

            /*employee.Add(emp);          // Replaced with SQLite line below
            WireUpEmployeeList();*/

            SqliteDataAccess.SaveEmployee(emp);

            eIDtextBox.Text = "";
            NameTextBox.Text = "";
            positionTextBox.Text = "";
            payRateTextBox.Text = "";
        }

        private void ascButton_Click(object sender, EventArgs e)
        {
            employee = SqliteDataAccess.SortASC();
            WireUpEmployeeList();
        }

        private void descButton_Click(object sender, EventArgs e)
        {
            employee = SqliteDataAccess.SortDESC();
            WireUpEmployeeList();
        }
    }
}
