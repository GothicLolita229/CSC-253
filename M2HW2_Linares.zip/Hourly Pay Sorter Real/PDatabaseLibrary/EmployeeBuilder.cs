﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PDatabaseLibrary
{
    public class EmployeeBuilder
    {
        public int EmployeeID { get; set; }
        public string Name { get; set; }
        public string Position { get; set; }
        public int Hourly { get; set; }

        public string Info
        {
            get
            {
                return $"{EmployeeID}, {Name}, {Position}, ${Hourly}/hr";
            }
        }
    }
}
