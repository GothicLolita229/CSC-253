﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PDatabaseLibrary
{
    public class SqliteDataAccess
    {
        public static List<EmployeeBuilder> LoadEmployees()
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var output = cnn.Query<EmployeeBuilder>("select * from Employee", new DynamicParameters());
                return output.ToList();
            }
                
        }

        public static List<EmployeeBuilder> SortASC()
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var output = cnn.Query<EmployeeBuilder>("select * from Employee ORDER BY Hourly ASC", new DynamicParameters());
                return output.ToList();
            }

        }

        public static List<EmployeeBuilder> SortDESC()
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var output = cnn.Query<EmployeeBuilder>("select * from Employee ORDER BY Hourly DESC", new DynamicParameters());
                return output.ToList();
            }

        }

        public static void SaveEmployee(EmployeeBuilder employee)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                cnn.Execute("insert into Employee (EmployeeID, Name, Position, Hourly) values (@EmployeeID, @Name, @Position, @Hourly)", employee);
            }
        }

        private static string LoadConnectionString(string id = "Default")
        {
            return ConfigurationManager.ConnectionStrings[id].ConnectionString;
        }
    }
}
