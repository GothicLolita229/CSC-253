﻿using KineticEnergyLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KineticEnergy
{
    /**
    * 8.21.2022
    * CSC 253
    * Lourdes Linares
    * References Class Library and calculates the amount of kinetic energy that an object has
    */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calcButton_Click(object sender, EventArgs e)
        {
            double mass;
            double velocity;
            double energy;

            

            if (double.TryParse(massTextBox.Text, out mass))
            {
                //Get velocity
                if (double.TryParse(velocityTextBox.Text, out velocity))
                {
                    energy = KEnergyCalc.KineticEnergy(mass, velocity);
                    kineticEnergyLabel.Text = energy.ToString("n1");
                }
                else
                {
                    MessageBox.Show("Velocity is invalid");
                }
            }
            else
            {
                MessageBox.Show("Mass is invalid");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

}
