﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KineticEnergyLibrary
{
    public class KEnergyCalc
    {
        public static double KineticEnergy(double m, double v)
        {
            return 0.5 * m * Math.Pow(v, 2.0);
        }
    }
}
