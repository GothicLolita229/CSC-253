﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UWLibrary
{
    public class ReadFile
    {
        public static List<string> uniqueWords = new List<string>();
        public static void FileReader(string file)
        {
            List<string> words = new List<string>();

            StreamReader rdr = File.OpenText(file);

            while(!rdr.EndOfStream)
            {
                string text = rdr.ReadLine().ToLower();

                string[] tokens = text.Split(' ');

                for(int i = 0; i < tokens.Length - 1; i++)
                {
                    if(char.IsPunctuation(tokens[i][tokens[i].Length - 1]))
                    {
                        tokens[i] = tokens[i].Remove(tokens[i].Length - 1, 1);
                    }

                    if (char.IsPunctuation(tokens[i][tokens[i].Length - tokens[i].Length]))
                    {
                        tokens[i] = tokens[i].Remove(tokens[i].Length - tokens[i].Length, 1);
                    }

                    words.Add(tokens[i]);
                }
            }
            rdr.Close();

            var sortedWords = from w in words
                              orderby w
                              select w;

            foreach (string sWord in sortedWords.Distinct())
            {
                uniqueWords.Add(sWord);
            }
        }
    }
}
