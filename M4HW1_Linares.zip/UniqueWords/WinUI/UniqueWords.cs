﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UWLibrary;
/**
* 10.21.2022
* CSC 253
* Lourdes Linares
* Selects and displays all unique words in any given file
*/
namespace WinUI
{
    public partial class UniqueWords : Form
    {
        //List<string> uniqueWords = new List<string>();
        public UniqueWords()
        {
            InitializeComponent();
        }


        private void FindButton_Click(object sender, EventArgs e)
        {
            openFileDialog.InitialDirectory = ".";

            if(openFileDialog.ShowDialog() == DialogResult.OK)
            {
                ReadFile.FileReader(openFileDialog.FileName);

                wordsListBox.Items.Clear();

                foreach(string word in ReadFile.uniqueWords)
                {
                    wordsListBox.Items.Add(word);
                }
            }
        }

        private void CloseButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
