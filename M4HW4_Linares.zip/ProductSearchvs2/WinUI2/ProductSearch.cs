﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/**
 * 10.30.2022
 * CSC 253
 * Lourdes Linares
 * Search products database by product number or description
 */
namespace WinUI2
{
    public partial class ProductSearch : Form
    {
        //List<Product> products = new List<Product>();
        public ProductSearch()
        {
            InitializeComponent();
            Display();
        }

        public void Display()
        {
            DisplayLB.Items.Clear();
            ProductDataContext db = new ProductDataContext();
            var products = from product in db.Products
                          select product;
            //List<Product> products = new List<Product>();
            foreach (var p in products)
            {
                //products.Add(result);
                DisplayLB.Items.Add($"Product Number: {p.Product_Number} *** Description: {p.Description} *** " +
                    $"Units On Hand: {p.Units_On_Hand} *** Price: {p.Price}");
            }

        }
        private void CLoseButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            DisplayLB.Items.Clear();
            DescSearchTB.Text = "";
            //Search by Number
            ProductDataContext db = new ProductDataContext();
            var products = from product in db.Products
                            where product.Product_Number == NumberSearchTB.Text
                            select product;
            //List<Product> resultList = new List<Product>();
            foreach (var p in products)
            {
                DisplayLB.Items.Add($"Product Number: {p.Product_Number} *** Description: {p.Description} *** " +
                    $"Units On Hand: {p.Units_On_Hand} *** Price: {p.Price}");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DisplayLB.Items.Clear();
            NumberSearchTB.Text = "";
            //Search by Description
            ProductDataContext db = new ProductDataContext();
            var products = from product in db.Products
                            where product.Description.Contains(DescSearchTB.Text)
                            select product;
            foreach (var p in products)
            {
                DisplayLB.Items.Add($"Product Number: {p.Product_Number} *** Description: {p.Description} *** " +
                    $"Units On Hand: {p.Units_On_Hand} *** Price: {p.Price}");
            }



        }
    }
}
