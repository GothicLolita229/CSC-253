﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarClassLibrary
{
    public class Car
    {
        public Car(int year, string make, int speed)
        {
            Year = year;
            Make = make;
            Speed = 0;
        }
        public int Year { get; set; }
        public string Make { get; set; }
        public int Speed { get; set; }

        public void Accelerate()
        {
             Speed += 5;
        }

        public void Brake()
        {
            Speed -= 5;
        }
    }
}
