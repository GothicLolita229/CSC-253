﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CarClassLibrary;


/**
* 8.28.2022
* CSC 253
* Lourdes Linares
* Accelerates and decelerates car by 5mph
*/



namespace CarClass
{
    public partial class Form1 : Form
    {
        Car myCar = new Car(1997, "Jaguar", 0);
        public Form1()
        {
            InitializeComponent();
        }

        private void accelerateButton_Click(object sender, EventArgs e)
        {
            myCar.Year = int.Parse(yearTextBox.Text);
            myCar.Make = makeTextBox.Text;
            myCar.Accelerate();
            int speed = myCar.Speed;
            speedLabel.Text = "Your " + myCar.Year + " " + myCar.Make + " is going " + speed + "mph";
        }

        

        private void breakButton_Click(object sender, EventArgs e)
        {
            myCar.Year = int.Parse(yearTextBox.Text);
            myCar.Make = makeTextBox.Text;
            myCar.Brake();
            int speed = myCar.Speed;
            speedLabel.Text = "Your " + myCar.Year + " " + myCar.Make + " is going " + speed + "mph";
        }
    }
}
