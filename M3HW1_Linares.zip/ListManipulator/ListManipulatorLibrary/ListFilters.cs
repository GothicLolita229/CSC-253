﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListManipulatorLibrary
{
    public class ListFilters
    {
        
        public static List<int> ReadFile()
        {
            List<int> numberList = new List<int>();
            StreamReader file = File.OpenText("random.txt");
            while(!file.EndOfStream)
            {
                numberList.Add(int.Parse(file.ReadLine()));
            }
            file.Close();
            return numberList;
        }

        public static List<int> RemoveNegative(List<int> numberList)
        {
            numberList.RemoveAll(n => n < 0);
            return numberList;
        }

        public static List<int> OneThruTenDisplay(List<int> numberList)
        {
            List<int> modifiedList = numberList.FindAll(n => n >= 1 && n <= 10);
            return modifiedList;
        }
    }
}
