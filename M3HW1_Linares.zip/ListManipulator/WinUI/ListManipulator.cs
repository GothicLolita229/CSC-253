﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ListManipulatorLibrary;

/**
* 9.30.2022
* CSC 253
* Lourdes Linares
* This application reads the contents of a file into a list. It then removes all negative numbers and creates a 
* second list within the range of 1 thru 10 and displays them in a ListBox
*/
namespace WinUI
{
    public partial class ListManipulator : Form
    {
        public ListManipulator()
        {
            InitializeComponent();
        }

        private void ListManipulator_Load(object sender, EventArgs e)
        {
            List<int> numbersList = ListFilters.ReadFile();
            ListFilters.RemoveNegative(numbersList);
            List<int> displayList = ListFilters.OneThruTenDisplay(numbersList);
            foreach(int i in displayList)
            {
                ResultsListBox.Items.Add(i);
            }

        }

        private void CloseButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
