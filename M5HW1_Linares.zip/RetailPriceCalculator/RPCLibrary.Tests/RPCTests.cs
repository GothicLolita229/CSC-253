﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RetailPriceCalculatorLibrary;
using Xunit;

namespace RPCLibrary.Tests
{
    public class RPCTests
    {
        [Fact]
        public void ShouldCalculateRetail()
        {
            //Arrange 
            double expected = 6.05;
            //Act
            double actual = Calculator.CalculateRetail(5.5, 10.0);
            //Assert
            Assert.Equal(expected, actual);
        }
    }
}
