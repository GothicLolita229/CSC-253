﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RetailPriceCalculatorLibrary;

/**
* 11/12/2022
* CSC 253
* Lourdes Linares
* Unit tests a program that calculates retail price from wholesale and markup
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void calculateButton_Click(object sender, EventArgs e)
        {
            //Calculator maths = new Calculator(); 
            // if method in class is not static you need to declare a new instance of object
            try
            {
                double.TryParse(wholesaleTextBox.Text, out double wholesalePrice);
                double.TryParse(markupTextBox.Text, out double markupPercentage);
                double retailPrice = Calculator.CalculateRetail(wholesalePrice, markupPercentage);
                displayTotal.Text = retailPrice.ToString("c");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
