﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* RETAIL PRICE CALCULATOR
 * Create an application that lets the user enter an item’s wholesale cost and its markup percentage. 
 * It should then display the item’s retail price. For example:
 * If an item’s wholesale cost is $5.00 and its markup percentage is 100 percent, then the item’s retail price is $10.00.
 * If an item’s wholesale cost is $5.00 and its markup percentage is 50 percent, then the item’s retail price is $7.50.
 * The program should have a method named CalculateRetail that receives the wholesale cost and the markup percentage as
 * arguments and returns the retail price of the item. 
*/

namespace RetailPriceCalculatorLibrary
{
    public class Calculator
    {
        public static double CalculateRetail(double wholesaleCost, double markup)
        {
            double retailPrice;

            double markupPercentage = markup / 100;

            retailPrice = wholesaleCost + (wholesaleCost * markupPercentage);

            return retailPrice;
        }
    }
}
