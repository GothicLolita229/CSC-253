﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HPALibrary;
/**
 * 10.8.2022
 * CSC 253
 * Lourdes Linares
 * This program filters through the data of a house list
 * using Price, # of beds, # of baths, and sqftage to narrow it down
 */
namespace WinUI
{
    public partial class HousePriceAnalysis : Form
    {
        public HousePriceAnalysis()
        {
            InitializeComponent();
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            SearchResultsListBox.Items.Clear();
            List<House> searchedHousesList = ListFilters.houseList;
            double lowRange;
            double highRange;
            if (LowPriceText.TextLength != 0 && HighPriceText.TextLength !=0)
            {
                try
                {
                    lowRange = double.Parse(LowPriceText.Text);
                    highRange = double.Parse(HighPriceText.Text);
                    searchedHousesList = ListFilters.RangeSearchDisplayP(lowRange, highRange, searchedHousesList);
                }
                catch
                {
                    MessageBox.Show("Please enter a valid integer for the low range!","Error");
                }
            }
            if (LowBedText.TextLength != 0 && HighBedText.TextLength != 0)
            {
                try
                {
                    lowRange = double.Parse(LowBedText.Text);
                    highRange = double.Parse(HighBedText.Text);
                    searchedHousesList = ListFilters.RangeSearchDisplayBd(lowRange, highRange, searchedHousesList);
                }
                catch
                {
                    MessageBox.Show("Please enter a valid integer for the low range!", "Error");
                }
            }
            if (LowBathText.TextLength != 0 && HighBathText.TextLength != 0)
            {
                try
                {
                    lowRange = double.Parse(LowBathText.Text);
                    highRange = double.Parse(HighBathText.Text);
                    searchedHousesList = ListFilters.RangeSearchDisplayBt(lowRange, highRange, searchedHousesList);
                }
                catch
                {
                    MessageBox.Show("Please enter a valid integer for the low range!", "Error");
                }
            }
            if (LowSQFTText.TextLength != 0 && HighSQFTText.TextLength != 0)
            {
                try
                {
                    lowRange = double.Parse(LowSQFTText.Text);
                    highRange = double.Parse(HighSQFTText.Text);
                    searchedHousesList = ListFilters.RangeSearchDisplayS(lowRange, highRange, searchedHousesList);
                }
                catch
                {
                    MessageBox.Show("Please enter a valid integer for the low range!", "Error");
                }
            }
            foreach (var house in searchedHousesList)
            {
                SearchResultsListBox.Items.Add(house.HouseToString());
            }
        }
    }
}
