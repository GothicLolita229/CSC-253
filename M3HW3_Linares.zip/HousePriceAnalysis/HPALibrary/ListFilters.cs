﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HPALibrary
{
    public class ListFilters
    {
        public static List<House> houseList = FileReader();
        public static List<House> FileReader()
        {
            List<House> returnList = new List<House>();
            StreamReader inputfile;
            try
            {
                inputfile = File.OpenText("house_prices.csv");
                while (inputfile.EndOfStream == false)
                {
                    string[] tokens = inputfile.ReadLine().Split(',');
                    House house = new House
                    {
                        Price = ParseDouble(tokens[0]),
                        Bed = ParseDouble(tokens[1]),
                        Bath = ParseDouble(tokens[2]),
                        Sqft = ParseDouble(tokens[3])
                    };
                    returnList.Add(house);
                }
                inputfile.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error Reading File");
                MessageBox.Show(ex.Message);
            }
            return returnList;
        }

        public static List<House> RangeSearchDisplayP(double lowValue, double highValue, List<House> houseList)
        {
            List<House> searchedHousesList = houseList.FindAll(a => a.Price >= lowValue && a.Price <= highValue);
            return searchedHousesList;
        }

        public static List<House> RangeSearchDisplayBd(double lowValue, double highValue, List<House> houseList)
        {
            List<House> searchedHousesList = houseList.FindAll(a => a.Bed >= lowValue && a.Bed <= highValue);
            return searchedHousesList;
        }

        public static List<House> RangeSearchDisplayBt(double lowValue, double highValue, List<House> houseList)
        {
            List<House> searchedHousesList = houseList.FindAll(a => a.Bath >= lowValue && a.Bath <= highValue);
            return searchedHousesList;
        }

        public static List<House> RangeSearchDisplayS(double lowValue, double highValue, List<House> houseList)
        {
            List<House> searchedHousesList = houseList.FindAll(a => a.Sqft >= lowValue && a.Sqft <= highValue);
            return searchedHousesList;
        }


        public static double ParseDouble(string input)
        {
            double.TryParse(input, out double number);
            return number;
        }
    }
}
