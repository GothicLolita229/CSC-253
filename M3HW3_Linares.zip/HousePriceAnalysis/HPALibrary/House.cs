﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HPALibrary
{
    public class House
    {
        public House()
        {
        }

        public House(double price, double bed, double bath, double sqft)
        {
            Price = price;
            Bed = bed;
            Bath = bath;
            Sqft = sqft;
        }

        public double Price { get; set; }
        public double Bed { get; set; }
        public double Bath { get; set; }
        public double Sqft { get; set; }

        public string HouseToString()
        {
            string houseString = string.Format("{0:C}, ", Price) + string.Format("{0} bedrooms, ", Bed) +
                string.Format("{0} baths, ", Bath) + string.Format("{0} Sqft", Sqft);
            return houseString;
        }
    }
}
