﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UWLibrary;
/**
* 10.21.2022
* CSC 253
* Lourdes Linares
* Display a list of: 
*   All unique words in both files
*   All words that appear in both files
*   Words that are only in first file
*   Words that are only in second file
*   Words that are unique to either the first or 
*       second file so that there are no duplicates 
*       in the files combined
*/
namespace WinUI
{
    public partial class TextFileAnalysis : Form
    {
        List<string> fileOne = new List<string>();
        List<string> fileTwo = new List<string>();
        List<string> fileUTE = new List<string>();
        public TextFileAnalysis()
        {
            InitializeComponent();

        }
        private void CloseButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void FindButton_Click(object sender, EventArgs e)
        {
            openFileDialog.InitialDirectory = ".";
            openFileDialog.FilterIndex = 2;

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                fileOne = ReadFile.FileReader(openFileDialog.FileName);

                wordsListBox.Items.Clear();

                var sortedWords = from w in ReadFile.uniqueWords1
                                  orderby w
                                  select w;

                foreach (string word in sortedWords)
                {
                    //MessageBox.Show(word);
                    wordsListBox.Items.Add(word);
                    fileOne.Add(word);
                }
            }
        }
        private void Only1Button_Click(object sender, EventArgs e)
        {
            wordsListBox.Items.Clear();
            var display = fileOne.Except(fileTwo).ToList();

            foreach(string word in display)
            {
                wordsListBox.Items.Add(word);
                fileUTE.Add(word);
            }
        }
        private void Only2Button_Click(object sender, EventArgs e)
        {
            wordsListBox.Items.Clear();
            var display = fileTwo.Except(fileOne).ToList();

            foreach (string word in display)
            {
                wordsListBox.Items.Add(word);
                fileUTE.Add(word);
            }
        }
        private void AllWordsButton_Click(object sender, EventArgs e)
        {
            wordsListBox.Items.Clear();

            var sortedWords = from w in ReadFile.allWords
                              orderby w
                              select w;

            foreach (string word in sortedWords)
            {
                wordsListBox.Items.Add(word);
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog.InitialDirectory = ".";
            //openFileDialog.FilterIndex = 2;

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                ReadFile.FileReader2(openFileDialog.FileName);

                wordsListBox.Items.Clear();

                var sortedWords = from w in ReadFile.uniqueWords2
                                  orderby w
                                  select w;

                foreach (string word in sortedWords)
                {
                    wordsListBox.Items.Add(word);
                    fileTwo.Add(word);
                }
            }
        }

        private void UniqueToEachButton_Click_1(object sender, EventArgs e)
        {
            wordsListBox.Items.Clear();
            List<string> uniqueWords = ReadFile.uniqueWords1.Union(ReadFile.uniqueWords2).ToList();

            foreach (string word in uniqueWords)
            {
                wordsListBox.Items.Add(word);
            }
        }
    }
}
