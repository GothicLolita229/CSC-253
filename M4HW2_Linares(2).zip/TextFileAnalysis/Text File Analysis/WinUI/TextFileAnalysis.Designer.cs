﻿
namespace WinUI
{
    partial class TextFileAnalysis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.wordsListBox = new System.Windows.Forms.ListBox();
            this.CloseButton = new System.Windows.Forms.Button();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.FindButton = new System.Windows.Forms.Button();
            this.Only1Button = new System.Windows.Forms.Button();
            this.Only2Button = new System.Windows.Forms.Button();
            this.AllWordsButton = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.UniqueToEachButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // wordsListBox
            // 
            this.wordsListBox.Font = new System.Drawing.Font("Microsoft Tai Le", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wordsListBox.FormattingEnabled = true;
            this.wordsListBox.Location = new System.Drawing.Point(9, 15);
            this.wordsListBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.wordsListBox.Name = "wordsListBox";
            this.wordsListBox.Size = new System.Drawing.Size(270, 277);
            this.wordsListBox.TabIndex = 0;
            // 
            // CloseButton
            // 
            this.CloseButton.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CloseButton.Location = new System.Drawing.Point(156, 315);
            this.CloseButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.CloseButton.Name = "CloseButton";
            this.CloseButton.Size = new System.Drawing.Size(73, 25);
            this.CloseButton.TabIndex = 2;
            this.CloseButton.Text = "Close";
            this.CloseButton.UseVisualStyleBackColor = true;
            this.CloseButton.Click += new System.EventHandler(this.CloseButton_Click);
            // 
            // openFileDialog
            // 
            this.openFileDialog.FileName = "openFileDialog";
            // 
            // FindButton
            // 
            this.FindButton.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FindButton.Location = new System.Drawing.Point(9, 297);
            this.FindButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.FindButton.Name = "FindButton";
            this.FindButton.Size = new System.Drawing.Size(112, 25);
            this.FindButton.TabIndex = 3;
            this.FindButton.Text = "Find a File";
            this.FindButton.UseVisualStyleBackColor = true;
            this.FindButton.Click += new System.EventHandler(this.FindButton_Click);
            // 
            // Only1Button
            // 
            this.Only1Button.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Only1Button.Location = new System.Drawing.Point(156, 353);
            this.Only1Button.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Only1Button.Name = "Only1Button";
            this.Only1Button.Size = new System.Drawing.Size(101, 28);
            this.Only1Button.TabIndex = 6;
            this.Only1Button.Text = "Only 1st File";
            this.Only1Button.UseVisualStyleBackColor = true;
            this.Only1Button.Click += new System.EventHandler(this.Only1Button_Click);
            // 
            // Only2Button
            // 
            this.Only2Button.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Only2Button.Location = new System.Drawing.Point(156, 386);
            this.Only2Button.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Only2Button.Name = "Only2Button";
            this.Only2Button.Size = new System.Drawing.Size(101, 28);
            this.Only2Button.TabIndex = 7;
            this.Only2Button.Text = "Only 2nd File";
            this.Only2Button.UseVisualStyleBackColor = true;
            this.Only2Button.Click += new System.EventHandler(this.Only2Button_Click);
            // 
            // AllWordsButton
            // 
            this.AllWordsButton.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AllWordsButton.Location = new System.Drawing.Point(27, 353);
            this.AllWordsButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.AllWordsButton.Name = "AllWordsButton";
            this.AllWordsButton.Size = new System.Drawing.Size(76, 28);
            this.AllWordsButton.TabIndex = 8;
            this.AllWordsButton.Text = "All Words";
            this.AllWordsButton.UseVisualStyleBackColor = true;
            this.AllWordsButton.Click += new System.EventHandler(this.AllWordsButton_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(9, 327);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(112, 25);
            this.button1.TabIndex = 9;
            this.button1.Text = "Find 2nd File";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // UniqueToEachButton
            // 
            this.UniqueToEachButton.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UniqueToEachButton.Location = new System.Drawing.Point(11, 385);
            this.UniqueToEachButton.Margin = new System.Windows.Forms.Padding(2);
            this.UniqueToEachButton.Name = "UniqueToEachButton";
            this.UniqueToEachButton.Size = new System.Drawing.Size(112, 28);
            this.UniqueToEachButton.TabIndex = 10;
            this.UniqueToEachButton.Text = "UniqueToEach";
            this.UniqueToEachButton.UseVisualStyleBackColor = true;
            this.UniqueToEachButton.Click += new System.EventHandler(this.UniqueToEachButton_Click_1);
            // 
            // TextFileAnalysis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(278, 425);
            this.Controls.Add(this.UniqueToEachButton);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.AllWordsButton);
            this.Controls.Add(this.Only2Button);
            this.Controls.Add(this.Only1Button);
            this.Controls.Add(this.FindButton);
            this.Controls.Add(this.CloseButton);
            this.Controls.Add(this.wordsListBox);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "TextFileAnalysis";
            this.Text = "Text File Analysis";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox wordsListBox;
        private System.Windows.Forms.Button CloseButton;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.Button FindButton;
        private System.Windows.Forms.Button Only1Button;
        private System.Windows.Forms.Button Only2Button;
        private System.Windows.Forms.Button AllWordsButton;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button UniqueToEachButton;
    }
}

