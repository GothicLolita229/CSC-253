﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeLibrary;

/**
* 11.20.2022
* CSC 253
* Lourdes Linares
* Displays input about employee using class library and 
* constructors with info from text boxes with Winforms
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        //Employee employee = new Employee(name, dept, position, id);
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int.TryParse(idNumTxt.Text, out int id);
                string name = nameTxt.Text;
                string position = posTxt.Text;
                string department = deptTxt.Text;
                Employee employee = new Employee(name, department, position, id);
                DisplayBox.Text = employee.ToString();
                nameTxt.Text = "";
                posTxt.Text = "";
                deptTxt.Text = "";
                idNumTxt.Text = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                throw;
            }
        }

        private void RemoveButton_Click(object sender, EventArgs e)
        {
            nameTxt.Text = "";
            posTxt.Text = "";
            deptTxt.Text = "";
            idNumTxt.Text = "";
            DisplayBox.Text = "";
        }

        private void CloseButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
