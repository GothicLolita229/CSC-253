﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SurnamesLibrary
{
    public class DataSorter
    {
        public static List<string> FileReader()
        {
            List<string> returnList = new List<string>();
            StreamReader inputfile;
            try
            {
                inputfile = File.OpenText("surnames.txt");
                while (inputfile.EndOfStream == false)
                {
                    returnList.Add(inputfile.ReadLine());
                }
                inputfile.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return returnList;
        }

        public static List<string> SurnameCharSearchDisplay(string characters, List<string> surnameList)
        {
            List<string> modifiedList = surnameList.FindAll(a => a.StartsWith(characters, StringComparison.InvariantCultureIgnoreCase));
            return modifiedList;
        }

        public static List<string> SurnameSpecSearchDisplay(string characters, List<string> surnameList)
        {
            List<string> modifiedList = surnameList.FindAll(a => a.Equals(characters, StringComparison.OrdinalIgnoreCase));
            return modifiedList;
        }

        public static List<string> SurnameGrThanSearchDisplay(int length, List<string> surnameList)
        {
            List<string> modifiedList = surnameList.FindAll(a => a.Length > length);
            return modifiedList;
        }

        public static List<string> SurnameLessThanSearchDisplay(int length, List<string> surnameList)
        {
            List<string> modifiedList = surnameList.FindAll(a => a.Length < length);
            return modifiedList;
        }


    }
}
