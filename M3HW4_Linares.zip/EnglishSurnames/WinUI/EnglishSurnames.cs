﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SurnamesLibrary;
/**
 * 10.8.2022
 * CSC 253
 * Lourdes Linares
 * This program filters throught the surnames.txt and searches for a return list based on 
 * length(greater than or shorter than a specified length), names that begin with certain
 * characters, or specific names
 */

namespace WinUI
{
    public partial class EnglishSurnames : Form
    {
        public EnglishSurnames()
        {
            InitializeComponent();
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            SearchResultListBox.Items.Clear();
            List<string> surnames = DataSorter.FileReader();

            string searchCriteria;
            int lengthSearch;

            if(LengthGreaterThanTB.TextLength !=0)
            {
                try
                {
                    int.TryParse(LengthGreaterThanTB.Text, out lengthSearch);
                    surnames = DataSorter.SurnameGrThanSearchDisplay(lengthSearch, surnames);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            if (LengthLessThanTB.TextLength != 0)
            {
                try
                {
                    int.TryParse(LengthLessThanTB.Text, out lengthSearch);
                    surnames = DataSorter.SurnameLessThanSearchDisplay(lengthSearch, surnames);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            if (BeginsWithTB.TextLength != 0)
            {
                try
                {
                    searchCriteria = BeginsWithTB.Text;
                    surnames = DataSorter.SurnameCharSearchDisplay(searchCriteria, surnames);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            if (SpecificTB.TextLength != 0)
            {
                try
                {
                    searchCriteria = SpecificTB.Text;
                    surnames = DataSorter.SurnameCharSearchDisplay(searchCriteria, surnames);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            foreach(var name in surnames)
            {
                SearchResultListBox.Items.Add(name);
            }


        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            SearchResultListBox.Items.Clear();
            SpecificTB.Text = "";
            LengthGreaterThanTB.Text = "";
            LengthLessThanTB.Text = "";
            BeginsWithTB.Text = "";
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
