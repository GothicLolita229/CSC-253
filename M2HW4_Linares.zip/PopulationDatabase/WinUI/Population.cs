﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 9.18.2022
* CSC 253
* Lourdes Linares
* Allows user to enter, update, and remove data and to sort by ascending and descending population
* count, name, and get the lowest, highest, average, and total populations
*/

namespace WinUI
{
    public partial class Population : Form
    {
        public Population()
        {
            InitializeComponent();
        }

        private void cityBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.cityBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.populationDataSet);

        }

        private void Population_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'populationDataSet.City' table. You can move, or remove it, as needed.
            this.cityTableAdapter.Fill(this.populationDataSet.City);

        }

        private void CloseButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void sortASCButton_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.FillByPopulationAsc(this.populationDataSet.City);
        }

        private void sortDESCButton_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.FillByPopulationDesc(this.populationDataSet.City);
        }

        private void sortNameButton_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.FillByCityAsc(this.populationDataSet.City);
        }

        private void getTotalPopButton_Click(object sender, EventArgs e)
        {
            double totalPopulation;
            totalPopulation = (double)this.cityTableAdapter.TotalSumPopulation();
            MessageBox.Show("The total population of all the cities is " +
                string.Format("{0:#,0}", totalPopulation));
        }

        private void getAvgPopButton_Click(object sender, EventArgs e)
        {
            // Declare variable to hold avg pop
            double averagePopulation;
            // Get average
            averagePopulation = (double)this.cityTableAdapter.AveragePopulation();

            //display result
            MessageBox.Show("The average population of all the cities is " +
                string.Format("{0:#,0}", averagePopulation));
        }

        private void getHighestButton_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.FillByMaxPopulation(this.populationDataSet.City);
        }

        private void getLowestButton_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.FillByMinPopulation(this.populationDataSet.City);
        }
    }
}
