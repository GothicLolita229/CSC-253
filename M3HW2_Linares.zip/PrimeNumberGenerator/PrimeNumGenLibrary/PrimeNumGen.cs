﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrimeNumGenLibrary
{
    public class PrimeNumGen
    {
        public static List<int> IsPrime(List<int> numberList)
        {
            List<int> primeNums = new List<int>();
            primeNums = numberList.FindAll(CheckNum);
            return primeNums;
        }

        public static List<int> AllNumbers(int input)
        {
            List<int> numberList = new List<int>();
            for(int j = 2; j <= input; j++)
            { numberList.Add(j); }
            return numberList;
        }
        public static bool CheckNum(int input)
        {
            int a = 0;
            for (int k = 1; k <= input; k++)
            {
                if (input % k == 0)
                {
                    a++;
                }
            }
            if (a == 2)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
