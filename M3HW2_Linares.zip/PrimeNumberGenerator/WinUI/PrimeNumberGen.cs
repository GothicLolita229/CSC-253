﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PrimeNumGenLibrary;
/**
* 10.2.2022
* CSC 253
* Lourdes Linares
* Finds all the prime numbers between 2 and the user input
* and displays a list
*/
namespace WinUI
{
    public partial class PrimeNumberGenerator : Form
    {
        public PrimeNumberGenerator()
        {
            InitializeComponent();
        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            inputTextBox.Text = "";
            PrimeNumListBox.Items.Clear();
        }

        private void CLoseButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void EnterButton_Click(object sender, EventArgs e)
        {
            List<int> primeNumbers = new List<int>();
            int input = int.Parse(inputTextBox.Text);
            List<int> allNumbers = PrimeNumGen.AllNumbers(input);
            if (input < 1)
            {
                MessageBox.Show("Need an integer greater than 1");
            }
            else
            {
                primeNumbers = PrimeNumGen.IsPrime(allNumbers);
                foreach (int number in primeNumbers)
                { PrimeNumListBox.Items.Add(number); }
                
            }
        }
    }
}
