﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TILibrary;

/**
* 11.16.2022
* CSC 253
* Lourdes Linares
* Calculates Increase of tuition and then tests the results
* 
*/

namespace WinUI
{
    public partial class TuitionIncrease : Form
    {
        public TuitionIncrease()
        {
            InitializeComponent();
        }

        private void CalcB_Click(object sender, EventArgs e)
        {
            TuitionLB.Items.Clear();
            double tuition = 6000.00;
            for(int year = 1; year <= 5; year++)
            {
                tuition = Tuition.TuitionCalc(tuition);
                TuitionLB.Items.Add(tuition.ToString("c"));
                TuitionLB.Items.Add("\r\n\r\n" + "\n");
            }
        }
    }
}
