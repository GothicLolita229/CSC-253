﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TILibrary
{
    public class Tuition
    {
        public static double TuitionCalc(double tuition)
        {
            const double INCREASE_PER_YEAR = 0.02;

            tuition += (tuition * INCREASE_PER_YEAR);

            return tuition;
        }
    }
}
