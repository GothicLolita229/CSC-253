﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Tuition.Tests
{
    [TestClass()]
    public class TuitionTests
    {
        [TestMethod()]
        public void TuitionCalcTest()
        {
            double expected = 6120;

            double actual = TILibrary.Tuition.TuitionCalc(6000);

            Assert.AreEqual(expected, actual);

        }
    }
}