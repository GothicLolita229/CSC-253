﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace AreaClassLibrary
{
    public class CircleArea
    {
        private double _radius;
        private double _width;
        private double _length;
        private double _height;

        public CircleArea(double radius, double width, double length, double height)
        {
            _radius = radius;
            _width = width;
            _length = length;
            _height = height;
        }

        public double Radius { get; set; }
        public double Width { get; set; }
        public double Length { get; set; }
        public double Height { get; set; }

        public static double CircArea(double radius)
        {
            const double pi = Math.PI;
            double area;
            area = Math.Pow(radius, 2) * pi;
            return area;
        }

        public static double RectArea(double length, double width)
        {
            return length * width;
        }

        public static double CylArea(double radius, double height)
        {
            const double pi = Math.PI;
            double area;
            area = Math.Pow(radius, 2) * pi * (radius + height);
            return area;
        }

    }
}
