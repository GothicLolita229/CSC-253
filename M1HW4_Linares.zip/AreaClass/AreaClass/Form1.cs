﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AreaClassLibrary;

/**
* 8.28.2022
* CSC 253
* Lourdes Linares
* Takes the radius, length, width, and height values and calculates areas of circle,
* rectangle, and cylinder. 
* Additional note: There are two ways to calculate the area of a cylinder. Area of the
* curved surface and total area. I calculated the total area
*/

namespace AreaClass
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void circleButton_Click(object sender, EventArgs e)
        {
            double area = 0;
            double r = Double.Parse(radiusTextBox.Text);
            area = CircleArea.CircArea(r);

            MessageBox.Show("The area of your circle is " + area);
        }

        private void rectButton_Click(object sender, EventArgs e)
        {
            double area = 0;
            double l = Double.Parse(LengthTextBox.Text);
            double w = Double.Parse(widthTextBox.Text);
            area = CircleArea.RectArea(l,w);
            MessageBox.Show("The area of your rectangle is " + area);
        }

        private void cylButton_Click(object sender, EventArgs e)
        {
            double area = 0;
            double r = Double.Parse(radiusTextBox.Text);
            double h = Double.Parse(heightTextBox.Text);
            area = CircleArea.CylArea(r,h);
            MessageBox.Show("The area of your cylinder is " + area);
        }
    }
}
